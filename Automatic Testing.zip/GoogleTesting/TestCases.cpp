#define UNIT_TEST
#include <gtest/gtest.h>
#include "EliteDrive.cpp"

// =======================================================
// ===================== UNIT TESTING ====================
// =======================================================

// ---------- isChar ----------
TEST(UNIT_Testing, isChar_uppercase) {
    EXPECT_TRUE(isChar('A'));
}

TEST(UNIT_Testing, isChar_lowercase) {
    EXPECT_TRUE(isChar('z'));
}

TEST(UNIT_Testing, isChar_invalid_digit) {
    EXPECT_FALSE(isChar('5'));
}

TEST(UNIT_Testing, lowercase_mid) {
    EXPECT_TRUE(isChar('m'));
}

// ---------- isName ----------
TEST(UNIT_Testing, valid_name) {
    EXPECT_TRUE(isName("Ali"));
}

TEST(UNIT_Testing, invalid_name_digits) {
    EXPECT_FALSE(isName("Ali123"));
}

TEST(UNIT_Testing, empty_name) {
    EXPECT_TRUE(isName(""));
}

TEST(UNIT_Testing, special_character_name) {
    EXPECT_FALSE(isName("Ali@"));
}

// ---------- is_valid email ----------
TEST(UNIT_Testing, valid_email) {
    EXPECT_TRUE(is_valid("abc@gmail.com"));
}

TEST(UNIT_Testing, invalid_email_no_at) {
    EXPECT_FALSE(is_valid("abcgmail.com"));
}

TEST(UNIT_Testing, email_starts_with_digit) {
    EXPECT_FALSE(is_valid("1abc@gmail.com"));
}

TEST(UNIT_Testing, email_without_dot) {
    EXPECT_FALSE(is_valid("abc@gmailcom"));
}

TEST(UNIT_Testing, email_ending_dot) {
    EXPECT_FALSE(is_valid("abc@gmail."));
}

// =======================================================
// ===================== MODULE TESTING ==================
// =======================================================

// ---------------- GRAPH MODULE ----------------

TEST(MODULE_Testing, University_Road_to_Karsaz) {
    Graph g(20);
    g.addEdge(1, 2, 300);
    g.addEdge(2, 1, 300);

    vector<int> result = dijkstra(g, 1);
    EXPECT_EQ(result[2], 300);
}

TEST(MODULE_Testing, University_Road_to_Bahadurabad) {
    Graph g(20);
    g.addEdge(1, 3, 400);

    vector<int> result = dijkstra(g, 1);
    EXPECT_EQ(result[3], 400);
}

TEST(MODULE_Testing, intermediate_path) {
    Graph g(20);
    g.addEdge(1, 2, 300);
    g.addEdge(2, 3, 200);

    vector<int> result = dijkstra(g, 1);
    EXPECT_EQ(result[3], 500);
}

TEST(MODULE_Testing, shortest_path_selection) {
    Graph g(20);
    g.addEdge(1, 2, 300);
    g.addEdge(2, 3, 200);
    g.addEdge(1, 3, 1000);

    vector<int> result = dijkstra(g, 1);
    EXPECT_EQ(result[3], 500);
}

// ---------------- CAR MODULE ----------------

TEST(MODULE_Testing, car_1_passenger) {
    CarList cl;
    cl.addCar("Bike", "Red", 1);
    EXPECT_TRUE(cl.assignCar(1));
}

TEST(MODULE_Testing, car_4_passengers) {
    CarList cl;
    cl.addCar("BMW", "Black", 4);
    EXPECT_TRUE(cl.assignCar(4));
}

TEST(MODULE_Testing, larger_car_match) {
    CarList cl;
    cl.addCar("Audi", "White", 5);
    EXPECT_TRUE(cl.assignCar(3));
}

TEST(MODULE_Testing, no_suitable_car) {
    CarList cl;
    cl.addCar("Honda", "White", 4);
    EXPECT_FALSE(cl.assignCar(10));
}

TEST(MODULE_Testing, exact_capacity_match) {
    CarList cl;
    cl.addCar("Corolla", "White", 5);
    EXPECT_TRUE(cl.assignCar(5));
}

// ---------------- RIDE LIST MODULE ----------------

TEST(MODULE_Testing, add_ride) {
    RideLinkedList list;
    EXPECT_NO_THROW(list.Add_ride(1001));
}

TEST(MODULE_Testing, multiple_insert) {
    RideLinkedList list;
    EXPECT_NO_THROW(list.Add_ride(111));
    EXPECT_NO_THROW(list.Add_ride(222));
    EXPECT_NO_THROW(list.Add_ride(333));
}

TEST(MODULE_Testing, delete_ride_existing) {
    RideLinkedList list;
    list.Add_ride(1001);
    EXPECT_NO_THROW(list.delete_ride(1001));
}

TEST(MODULE_Testing, delete_ride_missing) {
    RideLinkedList list;
    EXPECT_NO_THROW(list.delete_ride(9999));
}

// =======================================================
// ================= INTEGRATION TESTING ================
// =======================================================

TEST(INTEGRATION_Testing, booking_flow) {
    CarList cl;
    RideLinkedList list;

    cl.addCar("BMW", "Black", 4);

    bool booked = cl.assignCar(2);

    if (booked) {
        list.Add_ride(5001);
    }

    EXPECT_TRUE(booked);
}

TEST(INTEGRATION_Testing, fare_system) {
    Graph g(20);

    g.addEdge(1, 2, 300);
    g.addEdge(2, 4, 500);

    vector<int> fare = dijkstra(g, 1);
    EXPECT_EQ(fare[4], 800);
}

TEST(INTEGRATION_Testing, validation_system) {
    EXPECT_TRUE(isName("Ahmed"));
    EXPECT_TRUE(is_valid("ahmed@gmail.com"));
}

// =======================================================
// ================= BOUNDARY TESTING ===================
// =======================================================

TEST(BOUNDARY_Testing, min_passenger) {
    CarList cl;
    cl.addCar("Bike", "Red", 1);
    EXPECT_TRUE(cl.assignCar(1));
}

TEST(BOUNDARY_Testing, max_passenger) {
    CarList cl;
    cl.addCar("Van", "White", 15);
    EXPECT_TRUE(cl.assignCar(15));
}

TEST(BOUNDARY_Testing, above_limit) {
    CarList cl;
    cl.addCar("Van", "White", 15);
    EXPECT_FALSE(cl.assignCar(16));
}

TEST(BOUNDARY_Testing, NIC_length) {
    string nic = "1234567890123";
    EXPECT_EQ(nic.length(), 13);
}

TEST(BOUNDARY_Testing, phone_length) {
    string phone = "03123456789";
    EXPECT_EQ(phone.length(), 11);
}

// =======================================================
// ================= NEGATIVE TESTING ===================
// =======================================================

TEST(NEGATIVE_Testing, invalid_pickup) {
    int pickup = 15;
    EXPECT_FALSE(pickup >= 1 && pickup <= 13);
}

TEST(NEGATIVE_Testing, invalid_destination) {
    int dest = -2;
    EXPECT_FALSE(dest >= 1 && dest <= 13);
}

TEST(NEGATIVE_Testing, empty_email) {
    EXPECT_FALSE(is_valid(""));
}

// =======================================================
// ================= FUNCTIONAL TESTING =================
// =======================================================

TEST(FUNCTIONAL_Testing, booking_system) {
    CarList cl;
    RideLinkedList list;

    cl.addCar("Audi", "White", 4);

    bool assigned = cl.assignCar(3);

    if (assigned) {
        list.Add_ride(1001);
    }

    EXPECT_TRUE(assigned);
}

TEST(FUNCTIONAL_Testing, fare_calculation) {
    Graph g(20);

    g.addEdge(1, 2, 300);
    g.addEdge(2, 4, 500);

    vector<int> fare = dijkstra(g, 1);
    EXPECT_EQ(fare[4], 800);
}
// =======================================================
// ? FAILING TEST CASES - UNIT TESTING
// =======================================================

TEST(FAIL_Testing, Empty_name_should_be_invalid) {
	EXPECT_FALSE(isName("")); // ? should FAIL because your production code returns true for ""
}

// =======================================================
// ? FAILING TEST CASES - GRAPH MODULE
// =======================================================

TEST(FAIL_Testing, Unreachable_node_should_not_have_valid_distance) {
	Graph g(10);
	g.addEdge(1, 2, 100);

	vector<int> dist = dijkstra(g, 1);
	EXPECT_NE(dist[5], INT_MAX); // ? should FAIL because dist[5] is INT_MAX (unreachable)
}

TEST(FAIL_Testing, Wrong_shortest_path_expectation) {
	Graph g(10);
	g.addEdge(1, 2, 100);
	g.addEdge(2, 3, 100);

	vector<int> dist = dijkstra(g, 1);
	EXPECT_EQ(dist[3], 100); // ? WRONG (actual is 200, so it will fail)
}

TEST(FAIL_Testing, Negative_weight_edge_should_be_accepted) {
	Graph g(10);
	g.addEdge(1, 2, -50); // ? invalid logically

	vector<int> dist = dijkstra(g, 1);
	EXPECT_GE(dist[2], 0); // ? should fail since dist[2] will be negative (-50)
}

// =======================================================
// ? FAILING TEST CASES - CAR MODULE
// =======================================================

TEST(FAIL_Testing, No_car_available_should_still_return_true) {
	CarList cl;
	cl.addCar("Bike", "Red", 1);

	EXPECT_TRUE(cl.assignCar(100)); // ? wrong expectation (returns false, so it fails)
}

TEST(FAIL_Testing, Exact_capacity_edge_case_failure) {
	CarList cl;
	cl.addCar("BMW", "Black", 4);

	EXPECT_TRUE(cl.assignCar(5)); // ? should fail since 5 passengers won't fit in capacity 4
}

// =======================================================
// ? FAILING TEST CASES - INTEGRATION
// =======================================================

TEST(FAIL_Testing, Booking_flow_without_car_should_still_succeed) {
	CarList cl;
	RideLinkedList list;

	bool booked = cl.assignCar(999); // false expected

	if (booked) {
		list.Add_ride(5001);
	}

	EXPECT_TRUE(booked); // ? should fail because booked is false
}

TEST(FAIL_Testing, Fare_mismatch_integration) {
	Graph g(10);
	g.addEdge(1, 2, 100);
	g.addEdge(2, 4, 100);

	vector<int> dist = dijkstra(g, 1);
	EXPECT_EQ(dist[4], 150); // ? wrong expected result (actual is 200)
}

TEST(FAIL_Testing, Invalid_registration_still_passes_system) {
	string name = "Ali123";
	string email = "wrongemail";

	EXPECT_TRUE(isName(name));    // ? wrong (contains digits, returns false)
	EXPECT_TRUE(is_valid(email));   // ? wrong (missing @ and dot, returns false)
}

// =======================================================
// ? FAILING TEST CASES - BOUNDARY TESTING
// =======================================================

TEST(FAIL_Testing, Extremely_large_passenger_count) {
	CarList cl;
	cl.addCar("Van", "White", 10);

	EXPECT_TRUE(cl.assignCar(100000)); // ? should fail (capacity exceeded)
}

TEST(FAIL_Testing, Zero_length_NIC_accepted) {
	string nic = "";
	EXPECT_EQ(nic.length(), 13); // ? wrong (length is 0, fails)
}

TEST(FAIL_Testing, Short_phone_accepted) {
	string phone = "123";
	EXPECT_EQ(phone.length(), 11); // ? wrong (length is 3, fails)
}

// =======================================================
// =================== MAIN RUNNER =======================
// =======================================================

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
