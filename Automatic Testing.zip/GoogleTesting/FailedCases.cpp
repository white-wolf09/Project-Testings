#define UNIT_TEST
#include <gtest/gtest.h>
#include "EliteDrive.cpp"

// =======================================================
// ? FAILING TEST CASES - UNIT TESTING
// =======================================================

TEST(FAIL_Testing, Empty_name_should_be_invalid) {
	EXPECT_FALSE(isName("")); // ? should FAIL because your production code returns true for ""
}

// =======================================================
// ? FAILING TEST CASES - GRAPH MODULE
// =======================================================

TEST(FAIL_Testing, Unreachable_node_should_not_have_valid_distance) {
	Graph g(10);
	g.addEdge(1, 2, 100);

	vector<int> dist = dijkstra(g, 1);
	EXPECT_NE(dist[5], INT_MAX); // ? should FAIL because dist[5] is INT_MAX (unreachable)
}

TEST(FAIL_Testing, Wrong_shortest_path_expectation) {
	Graph g(10);
	g.addEdge(1, 2, 100);
	g.addEdge(2, 3, 100);

	vector<int> dist = dijkstra(g, 1);
	EXPECT_EQ(dist[3], 100); // ? WRONG (actual is 200, so it will fail)
}

TEST(FAIL_Testing, Negative_weight_edge_should_be_accepted) {
	Graph g(10);
	g.addEdge(1, 2, -50); // ? invalid logically

	vector<int> dist = dijkstra(g, 1);
	EXPECT_GE(dist[2], 0); // ? should fail since dist[2] will be negative (-50)
}

// =======================================================
// ? FAILING TEST CASES - CAR MODULE
// =======================================================

TEST(FAIL_Testing, No_car_available_should_still_return_true) {
	CarList cl;
	cl.addCar("Bike", "Red", 1);

	EXPECT_TRUE(cl.assignCar(100)); // ? wrong expectation (returns false, so it fails)
}

TEST(FAIL_Testing, Exact_capacity_edge_case_failure) {
	CarList cl;
	cl.addCar("BMW", "Black", 4);

	EXPECT_TRUE(cl.assignCar(5)); // ? should fail since 5 passengers won't fit in capacity 4
}

// =======================================================
// ? FAILING TEST CASES - INTEGRATION
// =======================================================

TEST(FAIL_Testing, Booking_flow_without_car_should_still_succeed) {
	CarList cl;
	RideLinkedList list;

	bool booked = cl.assignCar(999); // false expected

	if (booked) {
		list.Add_ride(5001);
	}

	EXPECT_TRUE(booked); // ? should fail because booked is false
}

TEST(FAIL_Testing, Fare_mismatch_integration) {
	Graph g(10);
	g.addEdge(1, 2, 100);
	g.addEdge(2, 4, 100);

	vector<int> dist = dijkstra(g, 1);
	EXPECT_EQ(dist[4], 150); // ? wrong expected result (actual is 200)
}

TEST(FAIL_Testing, Invalid_registration_still_passes_system) {
	string name = "Ali123";
	string email = "wrongemail";

	EXPECT_TRUE(isName(name));    // ? wrong (contains digits, returns false)
	EXPECT_TRUE(is_valid(email));   // ? wrong (missing @ and dot, returns false)
}

// =======================================================
// ? FAILING TEST CASES - BOUNDARY TESTING
// =======================================================

TEST(FAIL_Testing, Extremely_large_passenger_count) {
	CarList cl;
	cl.addCar("Van", "White", 10);

	EXPECT_TRUE(cl.assignCar(100000)); // ? should fail (capacity exceeded)
}

TEST(FAIL_Testing, Zero_length_NIC_accepted) {
	string nic = "";
	EXPECT_EQ(nic.length(), 13); // ? wrong (length is 0, fails)
}

TEST(FAIL_Testing, Short_phone_accepted) {
	string phone = "123";
	EXPECT_EQ(phone.length(), 11); // ? wrong (length is 3, fails)
}

// =======================================================
// =================== MAIN RUNNER =======================
// =======================================================

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}